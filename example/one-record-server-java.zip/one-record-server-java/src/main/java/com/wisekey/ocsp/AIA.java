package com.wisekey.ocsp;

/**
 * This class describes Authority Information Access Extension
 */
class AIA {
  public String Issuer;
  public String Ocsp;

  /**
   *
   */
  public AIA(String issuer, String ocsp) {
    Issuer = issuer;
    Ocsp = ocsp;
  }

  /**
   *
   */
  public AIA() {
    Issuer = "";
    Ocsp = "";
  }
}
