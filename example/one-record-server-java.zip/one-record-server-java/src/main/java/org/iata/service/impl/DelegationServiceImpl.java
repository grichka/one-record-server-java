package org.iata.service.impl;

import org.iata.api.model.DelegationRequest;
import org.iata.service.DelegationService;
import org.springframework.stereotype.Service;

@Service
public class DelegationServiceImpl implements DelegationService {

  @Override
  public void delegateAccess(DelegationRequest delegationRequest) {
    // TODO
  }
}
